# supermercadoAPI
API REST para los productos de un supermercado
